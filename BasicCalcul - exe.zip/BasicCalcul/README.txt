Projekt vznikl pro platformu Windows za účelem studia.

Instalace i následné spouštění provádějte souborem setup.exe.
V některých případech antivirus zahlásí nebezpečný soubor.