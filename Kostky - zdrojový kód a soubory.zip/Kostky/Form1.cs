﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kostky
{
    public partial class Form1 : Form
    {
        private Bitmap[] diceImages = { Kostky.Properties.Resources.dice1, Kostky.Properties.Resources.dice2, 
                                        Kostky.Properties.Resources.dice3, Kostky.Properties.Resources.dice4, 
                                        Kostky.Properties.Resources.dice5, Kostky.Properties.Resources.dice6 };

        Random random = new Random();
        int playerRandom;
        int pcRandom;
        int playerScore;
        int pcScore;

        public Form1()
        {
            InitializeComponent();
        }

        private void lblReset_Click(object sender, EventArgs e)
        {
            pcScore = 0;
            playerScore = 0;
            lblPlayerScore.Text = playerScore.ToString();
            lblPcScore.Text = pcScore.ToString();
            lblResult.Text = "Úspěšně resetováno!";
        }

        private void btnThrow_Click(object sender, EventArgs e)
        {
            // Hod počítač
            pcRandom = random.Next(1, 7);
            displayPc.Image = diceImages[pcRandom - 1];
            
            // Hod hráč
            playerRandom = random.Next(1, 7);
            displayPlayer.Image = diceImages[playerRandom - 1];
            
            if(pcRandom > playerRandom)
            {
                lblResult.Text = "Počítač vyhrál =(";
                pcScore ++;
                lblPcScore.Text = pcScore.ToString();
            }
            else if(pcRandom < playerRandom)
            {
                lblResult.Text = "Vyhrál jsi =)";
                playerScore ++;
                lblPlayerScore.Text = playerScore.ToString();
            }
            else if(pcRandom == playerRandom)
            {
                lblResult.Text = "Remíza, zkus to znovu!";
            }

            if (pcScore == 5)
            {
                lblResult.Text = "Počítač jako první získal 5 bodů a vyhrál!";
                pcScore = 0;
                playerScore = 0;
                lblPlayerScore.Text = playerScore.ToString();
                lblPcScore.Text = pcScore.ToString();
            }
            else if (playerScore == 5)
            {
                lblResult.Text = "Jako první si získal 5 bodů a vyhrál jsi!";
                pcScore = 0;
                playerScore = 0;
                lblPlayerScore.Text = playerScore.ToString();
                lblPcScore.Text = pcScore.ToString();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }
    }
}
