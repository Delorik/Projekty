﻿namespace Kostky
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayPlayer = new System.Windows.Forms.PictureBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.displayPc = new System.Windows.Forms.PictureBox();
            this.lblPlayerThrow = new System.Windows.Forms.Label();
            this.lblPcThrow = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lblPlayerScore = new System.Windows.Forms.Label();
            this.lblPcScore = new System.Windows.Forms.Label();
            this.btnThrow = new System.Windows.Forms.Button();
            this.lblReset = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.displayPlayer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.displayPc)).BeginInit();
            this.SuspendLayout();
            // 
            // displayPlayer
            // 
            this.displayPlayer.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.displayPlayer.Image = global::Kostky.Properties.Resources.dice1;
            this.displayPlayer.Location = new System.Drawing.Point(332, 139);
            this.displayPlayer.Name = "displayPlayer";
            this.displayPlayer.Size = new System.Drawing.Size(250, 250);
            this.displayPlayer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.displayPlayer.TabIndex = 0;
            this.displayPlayer.TabStop = false;
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Segoe Print", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblTitle.Location = new System.Drawing.Point(30, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(162, 57);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Kostky";
            // 
            // displayPc
            // 
            this.displayPc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.displayPc.Image = global::Kostky.Properties.Resources.dice1;
            this.displayPc.Location = new System.Drawing.Point(645, 139);
            this.displayPc.Name = "displayPc";
            this.displayPc.Size = new System.Drawing.Size(250, 250);
            this.displayPc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.displayPc.TabIndex = 2;
            this.displayPc.TabStop = false;
            // 
            // lblPlayerThrow
            // 
            this.lblPlayerThrow.Font = new System.Drawing.Font("Segoe Print", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPlayerThrow.Location = new System.Drawing.Point(325, 97);
            this.lblPlayerThrow.Name = "lblPlayerThrow";
            this.lblPlayerThrow.Size = new System.Drawing.Size(257, 39);
            this.lblPlayerThrow.TabIndex = 3;
            this.lblPlayerThrow.Text = "Hráč hodil:";
            // 
            // lblPcThrow
            // 
            this.lblPcThrow.Font = new System.Drawing.Font("Segoe Print", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPcThrow.Location = new System.Drawing.Point(638, 97);
            this.lblPcThrow.Name = "lblPcThrow";
            this.lblPcThrow.Size = new System.Drawing.Size(257, 39);
            this.lblPcThrow.TabIndex = 4;
            this.lblPcThrow.Text = "Počítač hodil:";
            // 
            // lblScore
            // 
            this.lblScore.Font = new System.Drawing.Font("Segoe Print", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblScore.Location = new System.Drawing.Point(41, 160);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(132, 39);
            this.lblScore.TabIndex = 5;
            this.lblScore.Text = "Skóre:";
            // 
            // lbl1
            // 
            this.lbl1.Font = new System.Drawing.Font("Segoe Print", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbl1.Location = new System.Drawing.Point(78, 215);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(95, 39);
            this.lbl1.TabIndex = 6;
            this.lbl1.Text = "Hráč:";
            // 
            // lbl2
            // 
            this.lbl2.Font = new System.Drawing.Font("Segoe Print", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbl2.Location = new System.Drawing.Point(78, 254);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(114, 39);
            this.lbl2.TabIndex = 7;
            this.lbl2.Text = "Počítač:";
            // 
            // lblPlayerScore
            // 
            this.lblPlayerScore.Font = new System.Drawing.Font("Segoe Print", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPlayerScore.Location = new System.Drawing.Point(200, 211);
            this.lblPlayerScore.Name = "lblPlayerScore";
            this.lblPlayerScore.Size = new System.Drawing.Size(95, 39);
            this.lblPlayerScore.TabIndex = 8;
            this.lblPlayerScore.Text = "0";
            // 
            // lblPcScore
            // 
            this.lblPcScore.Font = new System.Drawing.Font("Segoe Print", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPcScore.Location = new System.Drawing.Point(200, 250);
            this.lblPcScore.Name = "lblPcScore";
            this.lblPcScore.Size = new System.Drawing.Size(95, 39);
            this.lblPcScore.TabIndex = 9;
            this.lblPcScore.Text = "0";
            // 
            // btnThrow
            // 
            this.btnThrow.Font = new System.Drawing.Font("Segoe Print", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnThrow.Location = new System.Drawing.Point(162, 337);
            this.btnThrow.Name = "btnThrow";
            this.btnThrow.Size = new System.Drawing.Size(133, 52);
            this.btnThrow.TabIndex = 10;
            this.btnThrow.Text = "HODIT";
            this.btnThrow.UseVisualStyleBackColor = true;
            this.btnThrow.Click += new System.EventHandler(this.btnThrow_Click);
            // 
            // lblReset
            // 
            this.lblReset.AutoSize = true;
            this.lblReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblReset.Font = new System.Drawing.Font("Segoe Print", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblReset.Location = new System.Drawing.Point(800, 487);
            this.lblReset.Name = "lblReset";
            this.lblReset.Size = new System.Drawing.Size(95, 30);
            this.lblReset.TabIndex = 11;
            this.lblReset.Text = "Resetovat";
            this.lblReset.Click += new System.EventHandler(this.lblReset_Click);
            // 
            // label1
            // 
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Segoe Script", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(883, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 43);
            this.label1.TabIndex = 12;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblResult
            // 
            this.lblResult.Font = new System.Drawing.Font("Segoe Print", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblResult.ForeColor = System.Drawing.Color.Red;
            this.lblResult.Location = new System.Drawing.Point(59, 438);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(806, 57);
            this.lblResult.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(939, 540);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblReset);
            this.Controls.Add(this.btnThrow);
            this.Controls.Add(this.lblPcScore);
            this.Controls.Add(this.lblPlayerScore);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.lblPcThrow);
            this.Controls.Add(this.lblPlayerThrow);
            this.Controls.Add(this.displayPc);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.displayPlayer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.displayPlayer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.displayPc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox displayPlayer;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.PictureBox displayPc;
        private System.Windows.Forms.Label lblPlayerThrow;
        private System.Windows.Forms.Label lblPcThrow;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lblPlayerScore;
        private System.Windows.Forms.Label lblPcScore;
        private System.Windows.Forms.Button btnThrow;
        private System.Windows.Forms.Label lblReset;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblResult;
    }
}

