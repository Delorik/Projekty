Program spustíte kliknutím na "setup.exe"






Tento projekt vznikl za účelem studia základních operací a práce s daty.

Adresář umí ukládat nové záznamy, které je následně možné upravovat či mazat. Umožňuje
vyhledání jich uložených záznamů, které vyhledává podle jakékoliv z hodnot.

Svou jednoduchostí může být adresář skvělým pomocníkem například makléřů či obchodníků,
kteří spravují velké množství kontaktů.
