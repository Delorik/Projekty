﻿namespace Adresář
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBoxTelefon = new System.Windows.Forms.TextBox();
            this.labelTelefon = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.labelEmail = new System.Windows.Forms.Label();
            this.textBoxPrijmeni = new System.Windows.Forms.TextBox();
            this.labelPrijmeni = new System.Windows.Forms.Label();
            this.textBoxJmeno = new System.Windows.Forms.TextBox();
            this.labelJmeno = new System.Windows.Forms.Label();
            this.labelHledat = new System.Windows.Forms.Label();
            this.textBoxHledat = new System.Windows.Forms.TextBox();
            this.buttonNovy = new System.Windows.Forms.Button();
            this.buttonUpravit = new System.Windows.Forms.Button();
            this.buttonUlozit = new System.Windows.Forms.Button();
            this.buttonSmazat = new System.Windows.Forms.Button();
            this.buttonZpet = new System.Windows.Forms.Button();
            this.contactBookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet = new Adresář.DataSet();
            this.jménoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.příjmeníDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.contactBookBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AutoGenerateColumns = false;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.jménoDataGridViewTextBoxColumn,
            this.příjmeníDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.telefonDataGridViewTextBoxColumn,
            this.iDDataGridViewTextBoxColumn});
            this.dataGridView.DataSource = this.contactBookBindingSource;
            this.dataGridView.Location = new System.Drawing.Point(322, 53);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersWidth = 51;
            this.dataGridView.RowTemplate.Height = 24;
            this.dataGridView.Size = new System.Drawing.Size(703, 354);
            this.dataGridView.TabIndex = 0;
            this.dataGridView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView_KeyDown);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBoxTelefon);
            this.panel1.Controls.Add(this.labelTelefon);
            this.panel1.Controls.Add(this.textBoxEmail);
            this.panel1.Controls.Add(this.labelEmail);
            this.panel1.Controls.Add(this.textBoxPrijmeni);
            this.panel1.Controls.Add(this.labelPrijmeni);
            this.panel1.Controls.Add(this.textBoxJmeno);
            this.panel1.Controls.Add(this.labelJmeno);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(292, 395);
            this.panel1.TabIndex = 1;
            // 
            // textBoxTelefon
            // 
            this.textBoxTelefon.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.contactBookBindingSource, "Telefon", true));
            this.textBoxTelefon.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxTelefon.Location = new System.Drawing.Point(33, 278);
            this.textBoxTelefon.Name = "textBoxTelefon";
            this.textBoxTelefon.Size = new System.Drawing.Size(199, 28);
            this.textBoxTelefon.TabIndex = 10;
            // 
            // labelTelefon
            // 
            this.labelTelefon.AutoSize = true;
            this.labelTelefon.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelTelefon.Location = new System.Drawing.Point(29, 252);
            this.labelTelefon.Name = "labelTelefon";
            this.labelTelefon.Size = new System.Drawing.Size(66, 23);
            this.labelTelefon.TabIndex = 9;
            this.labelTelefon.Text = "Telefon";
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.contactBookBindingSource, "Email", true));
            this.textBoxEmail.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxEmail.Location = new System.Drawing.Point(33, 203);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(199, 28);
            this.textBoxEmail.TabIndex = 8;
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelEmail.Location = new System.Drawing.Point(29, 177);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(60, 23);
            this.labelEmail.TabIndex = 7;
            this.labelEmail.Text = "E-mail";
            // 
            // textBoxPrijmeni
            // 
            this.textBoxPrijmeni.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.contactBookBindingSource, "Příjmení", true));
            this.textBoxPrijmeni.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxPrijmeni.Location = new System.Drawing.Point(33, 127);
            this.textBoxPrijmeni.Name = "textBoxPrijmeni";
            this.textBoxPrijmeni.Size = new System.Drawing.Size(199, 28);
            this.textBoxPrijmeni.TabIndex = 6;
            // 
            // labelPrijmeni
            // 
            this.labelPrijmeni.AutoSize = true;
            this.labelPrijmeni.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelPrijmeni.Location = new System.Drawing.Point(29, 101);
            this.labelPrijmeni.Name = "labelPrijmeni";
            this.labelPrijmeni.Size = new System.Drawing.Size(75, 23);
            this.labelPrijmeni.TabIndex = 5;
            this.labelPrijmeni.Text = "Příjmení";
            // 
            // textBoxJmeno
            // 
            this.textBoxJmeno.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.contactBookBindingSource, "Jméno", true));
            this.textBoxJmeno.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxJmeno.Location = new System.Drawing.Point(33, 57);
            this.textBoxJmeno.Name = "textBoxJmeno";
            this.textBoxJmeno.Size = new System.Drawing.Size(199, 28);
            this.textBoxJmeno.TabIndex = 4;
            // 
            // labelJmeno
            // 
            this.labelJmeno.AutoSize = true;
            this.labelJmeno.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelJmeno.Location = new System.Drawing.Point(29, 31);
            this.labelJmeno.Name = "labelJmeno";
            this.labelJmeno.Size = new System.Drawing.Size(58, 23);
            this.labelJmeno.TabIndex = 0;
            this.labelJmeno.Text = "Jméno";
            // 
            // labelHledat
            // 
            this.labelHledat.AutoSize = true;
            this.labelHledat.Font = new System.Drawing.Font("Palatino Linotype", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelHledat.Location = new System.Drawing.Point(318, 12);
            this.labelHledat.Name = "labelHledat";
            this.labelHledat.Size = new System.Drawing.Size(66, 23);
            this.labelHledat.TabIndex = 2;
            this.labelHledat.Text = "Hledat:";
            // 
            // textBoxHledat
            // 
            this.textBoxHledat.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxHledat.Location = new System.Drawing.Point(403, 11);
            this.textBoxHledat.Name = "textBoxHledat";
            this.textBoxHledat.Size = new System.Drawing.Size(334, 28);
            this.textBoxHledat.TabIndex = 5;
            this.textBoxHledat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxHledat_KeyPress);
            // 
            // buttonNovy
            // 
            this.buttonNovy.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonNovy.Location = new System.Drawing.Point(24, 444);
            this.buttonNovy.Name = "buttonNovy";
            this.buttonNovy.Size = new System.Drawing.Size(203, 47);
            this.buttonNovy.TabIndex = 6;
            this.buttonNovy.Text = "Nový záznam";
            this.buttonNovy.UseVisualStyleBackColor = true;
            this.buttonNovy.Click += new System.EventHandler(this.buttonNovy_Click);
            // 
            // buttonUpravit
            // 
            this.buttonUpravit.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonUpravit.Location = new System.Drawing.Point(248, 444);
            this.buttonUpravit.Name = "buttonUpravit";
            this.buttonUpravit.Size = new System.Drawing.Size(112, 47);
            this.buttonUpravit.TabIndex = 7;
            this.buttonUpravit.Text = "Upravit";
            this.buttonUpravit.UseVisualStyleBackColor = true;
            this.buttonUpravit.Click += new System.EventHandler(this.buttonUpravit_Click);
            // 
            // buttonUlozit
            // 
            this.buttonUlozit.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonUlozit.Location = new System.Drawing.Point(524, 444);
            this.buttonUlozit.Name = "buttonUlozit";
            this.buttonUlozit.Size = new System.Drawing.Size(112, 47);
            this.buttonUlozit.TabIndex = 8;
            this.buttonUlozit.Text = "Uložit";
            this.buttonUlozit.UseVisualStyleBackColor = true;
            this.buttonUlozit.Click += new System.EventHandler(this.buttonUlozit_Click);
            // 
            // buttonSmazat
            // 
            this.buttonSmazat.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonSmazat.Location = new System.Drawing.Point(383, 444);
            this.buttonSmazat.Name = "buttonSmazat";
            this.buttonSmazat.Size = new System.Drawing.Size(112, 47);
            this.buttonSmazat.TabIndex = 9;
            this.buttonSmazat.Text = "Smazat";
            this.buttonSmazat.UseVisualStyleBackColor = true;
            this.buttonSmazat.Click += new System.EventHandler(this.buttonSmazat_Click);
            // 
            // buttonZpet
            // 
            this.buttonZpet.Font = new System.Drawing.Font("Palatino Linotype", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonZpet.Location = new System.Drawing.Point(803, 12);
            this.buttonZpet.Name = "buttonZpet";
            this.buttonZpet.Size = new System.Drawing.Size(63, 27);
            this.buttonZpet.TabIndex = 10;
            this.buttonZpet.Text = "Zpět";
            this.buttonZpet.UseVisualStyleBackColor = true;
            this.buttonZpet.Click += new System.EventHandler(this.buttonZpet_Click);
            // 
            // contactBookBindingSource
            // 
            this.contactBookBindingSource.DataMember = "ContactBook";
            this.contactBookBindingSource.DataSource = this.dataSet;
            // 
            // dataSet
            // 
            this.dataSet.DataSetName = "DataSet";
            this.dataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // jménoDataGridViewTextBoxColumn
            // 
            this.jménoDataGridViewTextBoxColumn.DataPropertyName = "Jméno";
            this.jménoDataGridViewTextBoxColumn.HeaderText = "Jméno";
            this.jménoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.jménoDataGridViewTextBoxColumn.Name = "jménoDataGridViewTextBoxColumn";
            this.jménoDataGridViewTextBoxColumn.Width = 125;
            // 
            // příjmeníDataGridViewTextBoxColumn
            // 
            this.příjmeníDataGridViewTextBoxColumn.DataPropertyName = "Příjmení";
            this.příjmeníDataGridViewTextBoxColumn.HeaderText = "Příjmení";
            this.příjmeníDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.příjmeníDataGridViewTextBoxColumn.Name = "příjmeníDataGridViewTextBoxColumn";
            this.příjmeníDataGridViewTextBoxColumn.Width = 125;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.Width = 125;
            // 
            // telefonDataGridViewTextBoxColumn
            // 
            this.telefonDataGridViewTextBoxColumn.DataPropertyName = "Telefon";
            this.telefonDataGridViewTextBoxColumn.HeaderText = "Telefon";
            this.telefonDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.telefonDataGridViewTextBoxColumn.Name = "telefonDataGridViewTextBoxColumn";
            this.telefonDataGridViewTextBoxColumn.Width = 125;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Visible = false;
            this.iDDataGridViewTextBoxColumn.Width = 125;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 540);
            this.Controls.Add(this.buttonZpet);
            this.Controls.Add(this.buttonSmazat);
            this.Controls.Add(this.buttonUlozit);
            this.Controls.Add(this.buttonUpravit);
            this.Controls.Add(this.buttonNovy);
            this.Controls.Add(this.textBoxHledat);
            this.Controls.Add(this.labelHledat);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adresář";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.contactBookBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxTelefon;
        private System.Windows.Forms.Label labelTelefon;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox textBoxPrijmeni;
        private System.Windows.Forms.Label labelPrijmeni;
        private System.Windows.Forms.TextBox textBoxJmeno;
        private System.Windows.Forms.Label labelJmeno;
        private System.Windows.Forms.Label labelHledat;
        private System.Windows.Forms.TextBox textBoxHledat;
        private System.Windows.Forms.Button buttonNovy;
        private System.Windows.Forms.Button buttonUpravit;
        private System.Windows.Forms.Button buttonUlozit;
        private System.Windows.Forms.BindingSource contactBookBindingSource;
        private DataSet dataSet;
        private System.Windows.Forms.DataGridViewTextBoxColumn jménoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn příjmeníDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button buttonSmazat;
        private System.Windows.Forms.Button buttonZpet;
    }
}

