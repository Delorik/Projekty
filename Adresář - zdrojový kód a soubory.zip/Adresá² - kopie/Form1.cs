﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Adresář
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonNovy_Click(object sender, EventArgs e)
        {
            try
            {
                panel1.Enabled = true;
                App.ContactBook.AddContactBookRow(App.ContactBook.NewContactBookRow());
                contactBookBindingSource.MoveLast();
                textBoxJmeno.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Message",MessageBoxButtons.OK,MessageBoxIcon.Error);
                App.ContactBook.RejectChanges();
            }
        }

        private void buttonUpravit_Click(object sender, EventArgs e)
        {
            panel1.Enabled = true;
            textBoxJmeno.Focus();
        }

        private void buttonUlozit_Click(object sender, EventArgs e)
        {
            try
            {
                contactBookBindingSource.EndEdit();
                App.ContactBook.AcceptChanges();
                App.ContactBook.WriteXml(string.Format("{0}//data.dat", Application.StartupPath));
                panel1.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                App.ContactBook.RejectChanges();
            }

        }

        static DataSet db;
        protected static DataSet App
        {
            get
            {
                if (db == null)
                    db = new DataSet();
                return db;
            }
        }

        public void Form1_Load(object sender, EventArgs e)
        {
            string fileName = string.Format("{0}//data.dat", Application.StartupPath);
            if (File.Exists(fileName))
                App.ContactBook.ReadXml(fileName);
            contactBookBindingSource.DataSource = App.ContactBook;
            panel1.Enabled = false;
        }

        private void dataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Delete)
            {
                if (MessageBox.Show("Určitě chceš odstranit tento záznam?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    contactBookBindingSource.RemoveCurrent();
            }
        }

        private void textBoxHledat_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                if (!string.IsNullOrEmpty(textBoxHledat.Text))
                {
                    var query = from o in App.ContactBook
                                where o.Telefon == textBoxHledat.Text || o.Jméno.Contains(textBoxHledat.Text) || o.Příjmení.Contains(textBoxHledat.Text) || o.Email == textBoxHledat.Text
                                select o;
                    dataGridView.DataSource = query.ToList();
                }
                else
                    dataGridView.DataSource = contactBookBindingSource;
            }
        }

        private void buttonSmazat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Určitě chceš odstranit tento záznam?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                contactBookBindingSource.RemoveCurrent();
                App.ContactBook.AcceptChanges();
                App.ContactBook.WriteXml(string.Format("{0}//data.dat", Application.StartupPath));
                panel1.Enabled = false;
            }
            
            
        }

        private void buttonZpet_Click(object sender, EventArgs e)
        {
            dataGridView.DataSource = contactBookBindingSource;
            panel1.Enabled=false;
            textBoxHledat.Clear();
        }
    }
}
